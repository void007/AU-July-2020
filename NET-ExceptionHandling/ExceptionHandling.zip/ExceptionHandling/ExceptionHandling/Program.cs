﻿using System;
using System.IO;

namespace ExceptionHandling
{
    class Program
    {
        static readonly log4net.ILog log =

       log4net.LogManager.GetLogger

(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        static void Main(string[] args)
        {
            
            log.Info("This is exception handling prog.");
            string path = @"C:\Users\void\source\repos\ExceptionHandling\file.txt";//for reading purprose
            //string path = @"C:\Users\void\source\repos\ExceptionHandling\file1.txt";//for the error puspose 
            StreamReader sr = null;
            int error = 0;
            try
            {
                sr = new StreamReader(path);
                Console.WriteLine(sr.ReadToEnd());
            }
            catch (FileNotFoundException fileNotFoundEx)
            {
                error = 1;
                Console.WriteLine("File - " + fileNotFoundEx.FileName + " not found");
            }
            catch (Exception ex)
            {
                error = 1;
                Console.WriteLine(ex.GetType().Name);
                Console.WriteLine("");
                Console.WriteLine(ex.Message);
            }
            finally
            {
                if (sr != null)
                {
                    sr.Close();
                    if (error == 0)
                    {
                        log.Info("Completed without error !");
                    }
                    else
                    {
                        log.Error("Found error");
                    }
                }
            }
            //Console.Read();

        }
    }
}
